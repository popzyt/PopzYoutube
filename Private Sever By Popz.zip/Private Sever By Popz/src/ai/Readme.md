## Ogar Bots

Where bots and minions "brains" are located. Bots originaly came from Ogar and has been since improving in Ogar Ul. Minions are my own special sauce.



Todo
1. make the bots more human like (teaming)
