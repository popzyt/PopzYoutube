'use strict';
module.exports = class PlayerServer {
  constructor(gameServer) {
    this.gameServer = gameServer;

  }

  init() {

  }

  start() {

  }

  update(dt) {

  }
};
